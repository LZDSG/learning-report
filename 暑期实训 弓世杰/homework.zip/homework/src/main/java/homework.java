import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

public class homework {
    public static final String BASE_URL = "https://movie.douban.com/review/best/?start=";
    public static final int PAGE_SIZE = 10;
    public static void main(String[] args) throws InterruptedException {
        // 设置 chromeDriver
        System.setProperty("webdriver.chrome.driver", "E:\\chromedriver_win32\\chromedriver.exe");
        Map map = System.getenv();
        Properties properties = System.getProperties();
        // 设置为 headless 模式
        ChromeOptions chromeOptions = new ChromeOptions();
        chromeOptions.addArguments("--headless");
        WebDriver driver = new ChromeDriver(chromeOptions);

        for (int i = 0; i < 10; i++) {
            String url = BASE_URL + String.valueOf(i * PAGE_SIZE);
            driver.get(url);

            // 查找所有评论所在div并将其列入列表
            List<WebElement> reviews = driver.findElements(By.xpath("/html/body/div[3]/div[1]/div/div[1]/div[1]/div"));
            System.out.println(reviews.size());

            for (WebElement review : reviews) {
                //在当前 div 下查找所需元素
                String movieName = review.findElement(By.xpath("div/a/img")).getAttribute("title");
                String author = review.findElement(By.xpath("div/header/a[2]")).getText();
                String title = review.findElement(By.xpath("div/div/h2/a")).getText();
                System.out.println(movieName + " == " + author + " == " + title);
            }
        }

        // 获得当前窗口句柄
        String reviewWidow = driver.getWindowHandle();
        // 点击当前页面的登录链接进入登录页面
        driver.findElement(By.linkText("登录/注册")).click();
        Thread.sleep(3000);
        // 获得所有窗口句柄
        Set<String> handles = driver.getWindowHandles();
        // 判断是否为登录窗口, 并进行登录
        for (String handle : handles) {
            if (handle.equals(reviewWidow) == false) {
                //切换到登录页面
                driver.switchTo().window(handle);
            }
        }

        // 切换为密码登录
        driver.findElement(By.linkText("密码登录")).click();
        Thread.sleep(3000);
        // 输入测试用户名和密码
        driver.findElement(By.name("username")).clear();
        driver.findElement(By.name("username")).sendKeys("12345678911");
        driver.findElement(By.name("password")).clear();
        driver.findElement(By.name("password")).sendKeys("123456");

        Thread.sleep(2000);
        //关闭浏览器
        driver.close();
        driver.quit();
    }
}
